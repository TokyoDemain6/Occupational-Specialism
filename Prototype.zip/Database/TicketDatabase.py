import sqlite3 as lite
from datetime import *
#import helpers
#import UserDatabase
from Database import UserDatabase, helpers

def purchaseTicket(username, dateOfPurchase, dateOfVisit, paymentDetails):
    userData = UserDatabase.accessUserDataUsername(usernameVar=username)
    if paymentDetails["CardholderName"] == "" or paymentDetails["CCV"] == "" or paymentDetails["cardNum"] == "":
        print("F")
        return "failed"
    paymentDetails=helpers.dictToString(paymentDetails)
    con = lite.Connection("Database/TicketData.db")
    cur = con.cursor()
    dateOfVisit = date.strftime(datetime.strptime(dateOfVisit,"%m/%d/%y"),"%Y%m%d")
    dateOfPurchase = date.strftime(dateOfPurchase,"%Y%m%d")
    cur.execute(f"""CREATE TABLE IF NOT EXISTS dateofvisitis_{dateOfVisit} (ticketID PRIMARY KEY, username, dateOfPurchase, paymentDetails)""")
    con.commit()
    con = lite.Connection("Database/TicketData.db")
    cur = con.cursor()
    cur.execute(f"""INSERT INTO dateofvisitis_{dateOfVisit} VALUES (NULL,"{username}","{dateOfPurchase}","{paymentDetails}")""")
    con.commit()
    return "success"
    # --saves the ticket data

def getTicket(choice, data, date):
    con = lite.Connection("Database/TicketData.db")
    cur = con.cursor()
    if choice == "ticketID":
        return cur.execute(f"""SELECT * FROM {date} WHERE ticketID = {data}""").fetchall()
    else:
        return cur.execute(f"""SELECT * FROM {date} WHERE userID = {data}""").fetchall()
    # --returns the ticket data
