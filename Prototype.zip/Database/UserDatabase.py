import sqlite3 as lite
import Database.helpers as helpers
#import helpers

def createUser(username, password, email, phoneNumber):
    con = lite.Connection("Database/UserData.db")
    cur = con.cursor()
    cur.execute("""INSERT INTO accountInfo VALUES (NULL,"{username}", "{password}", "{email}", "{phoneNumber}")""".format(username = username, password = password, email = email, phoneNumber = phoneNumber))
    con.commit()
    # --used to create a user in the database

def deleteUser(username, password):
    con = lite.Connection("Database/Userdata.db")
    cur = con.cursor()
    cur.execute("""DELETE FROM accountInfo WHERE username = "{username}" and password = "{password}" """.format(username = username, password = password))
    con.commit()
    # --used to delete a user from the database, kept secure by requiring a password

def accessUserDataID(userID):
    con = lite.Connection("Database/UserData.db")
    cur = con.cursor()
    data = cur.execute("SELECT * FROM accountInfo WHERE userID = {userID}".format(userID = userID))
    return(data.fetchall())
    # --gets the user data based on id
    # TODO secure the system using the password to access the data

def accessUserDataUsername(usernameVar):
    con = lite.Connection("Database/UserData.db")
    cur = con.cursor()
    data = cur.execute(f"""SELECT * FROM accountInfo WHERE username = "{usernameVar}" """)
    return(data.fetchall())
    # --gets the user data based on username
    # TODO secure the system using the password to access the data

def login(username, password):
    con = lite.Connection("Database/UserData.db")
    cur = con.cursor()
    data = cur.execute("""Select * FROM accountInfo WHERE (username = "{username}" AND password = "{password}" )""".format(username=username,password=password)).fetchall()
    if data:
        return True, data[0][0]
    else:
        return False
    # --returns if the data entered is correct, this never tells the user the correct details
