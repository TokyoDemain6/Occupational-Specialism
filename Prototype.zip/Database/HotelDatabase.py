import sqlite3 as lite
import Database.helpers as helpers
import datetime as dt
from datetime import *
import traceback
import time

def createRoom(roomID):
    con = lite.Connection("Database/HotelData.db")
    cur = con.cursor()
    cur.execute(f"CREATE TABLE IF NOT EXISTS room{roomID} (occupant, dateOfEntry, dateOfDeparture, roomData)")
    con.commit()
    return True
    # --creates a room based off the roomID

def addCustomerRecord(roomID : int, occupant : str, lengthOfStay : int, dateOfEntry : dt.date, roomData : dict):
    if roomData["CardholderName"] == "" or roomData["CCV"] == "" or roomData["cardNum"] == "":
        print("F")
        return "failed"
    else:
        roomData = helpers.dictToString(roomData)
        con = lite.Connection("Database/HotelData.db")
        cur = con.cursor()
        cur.execute(f"""INSERT INTO {roomID} VALUES ("{occupant}", "{dateOfEntry}", "{lengthOfStay}", "{roomData}")""")
        con.commit()
        return "Success"
    # adds a customer record that saves all the required data

def dropTable(roomID):
    con = lite.Connection("Database/HotelData.db")
    cur = con.cursor()
    cur.execute(f"""DROP TABLE IF EXISTS room{roomID}""")
    con.commit()
    return True
    # --used to drop tables, not really needed just used for manipulating the database outside the app however is kept here as it is a useful funciton to have for the RZA to do database management


def populate(roomCount):
    con = lite.Connection("Database/HotelData.db")
    cur = con.cursor()
    for i in range(1, roomCount+1):
        cur.execute(f"""CREATE TABLE IF NOT EXISTS room{i} (occupant, dateOfEntry, lengthOfStay, roomData)""")
    con.commit()
    return True
    # --populates the database with all the room required

def getRoomData(roomID):
    con = lite.Connection("Database/HotelData.db")
    cur = con.cursor()
    roomdatareturn = cur.execute(f"SELECT * FROM {roomID}").fetchall()
    return roomdatareturn
    # --gets all the room data

def getTimeData(date : datetime.date, roomID : int):
    con = lite.Connection("Database/HotelTimingData.db")
    cur = con.cursor()
    data = cur.execute(f"""SELECT * FROM {roomID} WHERE date = "{date}" """).fetchall()
    if data[1] == True:
        return True
    else:
        return False
    # --gets the data based of the time entered as the second database is used for storing and returning weather the room is available
    
def populateTiming(date : dt.date):
    con = lite.Connection("Database/HotelData.db")
    cur = con.cursor()
    tableList = []
    tableList = cur.execute("""SELECT name FROM sqlite_master WHERE type="table" """).fetchall()
    date = date.isoformat()
    for table in tableList:
        try:
            con = lite.Connection("Database/HotelData.db")
            cur = con.cursor()
            name = cur.execute(f"""SELECT * FROM {table[0]} WHERE dateOfEntry <= "{date}" AND dateOfDeparture >= "{date}" """).fetchall()
            if name:
                name = name[0]
                name = name[3]
                name = helpers.stringToDict(name)
                name = name["roomNumber"]
                con = lite.Connection("Database/HotelTimingData.db")
                cur = con.cursor()
                cur.execute(f"""CREATE TABLE IF NOT EXISTS room{name} (Availability)""")
                con.commit()
                con = lite.Connection("Database/HotelTimingData.db")
                cur = con.cursor()
                cur.execute(f"""INSERT INTO room{name} VALUES ("TRUE")""")
                con.commit()
            else:
                pass
        except Exception as e:
            pass
    # --populates the timing database with the availablility of rooms based off the main databse and the date entered

def updateTiming(date : date):
    con = lite.Connection("Database/HotelData.db")
    cur = con.cursor()
    tableList = []
    tableList = cur.execute("""SELECT name FROM sqlite_master WHERE type="table" """).fetchall()
    dateiso = date.isoformat()
    date = (datetime.strptime(datetime.strftime(date, "%Y-%m-%d"), "%Y-%m-%d") - dt.datetime(1970,1,1)).total_seconds()
    for table in tableList:
        try:
            con = lite.Connection("Database/HotelData.db")
            cur = con.cursor()
            dates = cur.execute(f"""SELECT dateOfDeparture, dateOfEntry FROM {table[0]} """).fetchall()
            con.commit()
            entry = (datetime.strptime(dates[0][1], "%Y-%m-%d") - dt.datetime(1970,1,1)).total_seconds()
            Depar = (datetime.strptime(dates[0][0], "%Y-%m-%d") - dt.datetime(1970,1,1)).total_seconds()
            if int(date) in range(int(entry), int(Depar)):
                con = lite.Connection("Database/HotelTimingData.db")
                cur = con.cursor()
                cur.execute(f"""DELETE FROM {table[0]}""")
                cur.execute(f"""INSERT INTO {table[0]} VALUES ("TRUE")""")
                con.commit()
            else:
                con = lite.Connection("Database/HotelTimingData.db")
                cur = con.cursor()
                cur.execute(f"""DELETE FROM {table[0]} """)
                cur.execute(f"""INSERT INTO {table[0]} VALUES ("FALSE")""")
                con.commit()
        except Exception as e:
            pass
    con.close()
    # --used to remove any excess rows and update the rooms with if they are available

def checkAvilTime(dateVar : date, room):
    updateTiming(dateVar)
    con = lite.Connection("Database/HotelTimingData.db")
    cur = con.cursor()
    try:
        i = cur.execute(f"SELECT * FROM room{room}").fetchone()
        if i[0] == "TRUE":
            return True
        elif i[0] == "FALSE":
            return False
        else: 
            return None
    except:
        return True
    # --used to check if the room entered is available on the date entered 

        
def checkAvilNow(room):
    updateTiming(date.today())
    con = lite.Connection("Database/HotelTimingData.db")
    cur = con.cursor()
    i = cur.execute(f"SELECT * FROM room{room}").fetchone()
    if i[0] == "True":
        return True
    elif i[0] == "False":
        return False
    else: 
        return None
    # --used to check if the room us available now
    
def getRooms():
    con = lite.Connection("Database/HotelData.db")
    cur = con.cursor()
    tableList = []
    tableList = cur.execute("""SELECT name FROM sqlite_master WHERE type="table" """).fetchall()
    return tableList
    # gets all the rooms


