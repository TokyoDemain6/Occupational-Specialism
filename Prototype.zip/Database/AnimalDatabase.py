import sqlite3 as lite
import Database.helpers as helpers

# --DATABASE FORMATTING BELOW
# every animal type e.g. Dog, cat, penguin has a table of its own so they can be separeded from eachother easily
# every individual animal has a name, location, age, species, habitat and characteristic table
# characteristic table stores the data defined in Assets.Templates.AnimalDataTemplate


def addAnimalType(animal):
    con = lite.Connection("Database/AnimalData.db")
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS {animal} (name, location, age, species, habitat, characteristics)""".format(animal = animal))
    # --this function takes the animal type and creates a table for that animal type if it doesnt exist

def addAnimal(animal : str, name : str, location : str, age : str, species : str, habitat : str, characteristics: dict):
    con = lite.Connection("Database/AnimalData.db")
    cur = con.cursor()
    characteristicsStr = helpers.dictToString(characteristics)
    cur.execute("""INSERT INTO {animal} VALUES ("{name}","{location}", "{age}", "{species}", "{habitat}", "{characteristics}")""".format(animal = animal, name=name, location=location, age=age, species=species, habitat=habitat, characteristics = characteristicsStr))
    con.commit()
    # --this function takes the details added and adds them to the table corresponding to the animal type

def readAnimalType(animal):
    con = lite.Connection("Database/AnimalData.db")
    cur = con.cursor()
    return cur.execute(f"""SELECT * FROM {animal[0]}""").fetchall()
    # --reads all data in a animal type

def readAnimal(animalType, animalName):
    #try:
        con = lite.Connection("Database/AnimalData.db")
        cur = con.cursor()
        data = cur.execute(f"""SELECT * FROM {animalType} where name = "{animalName}" """).fetchall()
        char = data[0][5]
        char = helpers.stringToDict(char)
        data = list(data[0])
        data[5] = char
        return data
    #except Exception:
        #return ""
    # --this function returns the animal data

def readAnimalTables():
    con = lite.Connection("Database/AnimalData.db")
    cur = con.cursor()
    data = cur.execute(f"""SELECT name FROM sqlite_master WHERE type = "table" """).fetchall()
    return data
    # --returns all the table names