def dictToString(data):
    return f"{data}"

def stringToDict(data):
    return eval(data)