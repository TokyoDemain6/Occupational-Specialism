import customtkinter as CTk
from PIL import Image
import Database.TicketDatabase as td
import Database.HotelDatabase as hd
import datetime
import Code.Popups

class PurchaseTicketTopLevel(CTk.CTkToplevel):
    def __init__(self, master, username, dateOfVisit,ticketpop):
        super().__init__(master)
        # --Configure Window
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.geometry("600x600")
        self.resizable(False, False)

        # --create variables
        logoPath="Assets\images\LogoZebra.png"
        logo = CTk.CTkImage(light_image=Image.open(logoPath), size=(100, 100))

        # --Command for pressing pay
        def pay_callback():
            # --This will need to be implemented later so that the transactions can be made, however currently just saves purchase data
            purchaseData = {
                "cardNum" : self.cardNum.get(),
                "CCV" : self.CCV.get(),
                "CardholderName" : self.CardholderName.get()
            }
            td.purchaseTicket(username=username,dateOfPurchase=datetime.date.today(),dateOfVisit=dateOfVisit, paymentDetails=purchaseData)
            ticketpop.destroy()
        # --Command for pressing cancel
        def cancel_callback():
            # --just closes the toplevel to take the user back to date selection
            ticketpop.destroy()


        # --topBar
        self.top = CTk.CTkFrame(self, width=600, height=150)
        self.top.grid_propagate(False)
        self.logo = CTk.CTkLabel(self.top, image=logo, text="")
        self.logoText = CTk.CTkLabel(self.top, text="Ridget Zoo Adventures")
        self.topButton = CTk.CTkButton(self.top, 250, 72)
        
        # --MainFrame
        self.mainFrame = CTk.CTkFrame(self, 560, 400)
        self.mainFrame.grid_propagate(False)
        self.cardNum = CTk.CTkEntry(self.mainFrame, placeholder_text="Card Number", width=500, height=50)
        self.CCV = CTk.CTkEntry(self.mainFrame, placeholder_text="CCV", width=150, height=50)
        self.CardholderName = CTk.CTkEntry(self.mainFrame, placeholder_text="Card Holder Name", width=300, height=50)
        self.pay = CTk.CTkButton(self.mainFrame, text="Pay", width=150, height=50, command=lambda : pay_callback())
        self.cancel = CTk.CTkButton(self.mainFrame, text="Cancel",width=150, height=50, command=lambda : cancel_callback())

        # --Placement - Top
        self.top.grid(row=0,column=0,sticky="nw")
        self.logo.grid(row=0,column=0,padx=10,pady=10)
        self.logoText.grid(row=0,column=1,padx=10,pady=10)
        self.topButton.grid(row=0,column=2,padx=10,pady=10)

        # --Placement - MainFrame
        self.mainFrame.grid(row=1, column=0, sticky="new",padx=10,pady=10)
        self.cardNum.grid(row=0, column=0, columnspan=3,sticky="new",padx=10,pady=10)
        self.CCV.grid(row=1, column=0, sticky="nw",padx=10,pady=10)
        self.CardholderName.grid(row=1, column=1, columnspan=2,sticky="ne",padx=10,pady=10)
        self.pay.grid(row=2, column=0,sticky="nw",padx=10,pady=10)
        self.cancel.grid(row=2, column=2,sticky="ne",padx=10,pady=10)

class PurchaseHotelTopLevel(CTk.CTkToplevel):
    def __init__(self, master, username, dateOfVisit, room, lenofstay):
        super().__init__(master)
        # --Configure Window
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.geometry("600x600")
        self.resizable(False, False)

        # --create variables
        logoPath="Assets\images\LogoZebra.png"
        logo = CTk.CTkImage(light_image=Image.open(logoPath), size=(100, 100))

        # --Command for pressing pay
        def pay_callback():
            # --This will need to be implemented later so that the transactions can be made, however currently just saves purchase data
            purchaseData = {
                "cardNum" : self.cardNum.get(),
                "CCV" : self.CCV.get(),
                "CardholderName" : self.CardholderName.get()
            }
            check = hd.addCustomerRecord(roomID=room,occupant=username,dateOfEntry=dateOfVisit,lengthOfStay=lenofstay,roomData=purchaseData)
            print(check)
            if check == "failed":
                pass
            else:
                self.destroy()
        # --Command for pressing cancel
        def cancel_callback():
            # --just closes the toplevel to take the user back to date selection
            self.destroy()


        # --topBar
        self.top = CTk.CTkFrame(self, width=600, height=150)
        self.top.grid_propagate(False)
        self.logo = CTk.CTkLabel(self.top, image=logo, text="")
        self.logoText = CTk.CTkLabel(self.top, text="Ridget Zoo Adventures")
        self.topButton = CTk.CTkButton(self.top, 250, 72)
        
        # --MainFrame
        self.mainFrame = CTk.CTkFrame(self, 560, 400)
        self.mainFrame.grid_propagate(False)
        self.cardNum = CTk.CTkEntry(self.mainFrame, placeholder_text="Card Number", width=500, height=50)
        self.CCV = CTk.CTkEntry(self.mainFrame, placeholder_text="CCV", width=150, height=50)
        self.CardholderName = CTk.CTkEntry(self.mainFrame, placeholder_text="Card Holder Name", width=300, height=50)
        self.pay = CTk.CTkButton(self.mainFrame, text="Pay", width=150, height=50, command=lambda : pay_callback())
        self.cancel = CTk.CTkButton(self.mainFrame, text="Cancel",width=150, height=50, command=lambda : cancel_callback())

        # --Placement - Top
        self.top.grid(row=0,column=0,sticky="nw")
        self.logo.grid(row=0,column=0,padx=10,pady=10)
        self.logoText.grid(row=0,column=1,padx=10,pady=10)
        self.topButton.grid(row=0,column=2,padx=10,pady=10)

        # --Placement - MainFrame
        self.mainFrame.grid(row=1, column=0, sticky="new",padx=10,pady=10)
        self.cardNum.grid(row=0, column=0, columnspan=3,sticky="new",padx=10,pady=10)
        self.CCV.grid(row=1, column=0, sticky="nw",padx=10,pady=10)
        self.CardholderName.grid(row=1, column=1, columnspan=2,sticky="ne",padx=10,pady=10)
        self.pay.grid(row=2, column=0,sticky="nw",padx=10,pady=10)
        self.cancel.grid(row=2, column=2,sticky="ne",padx=10,pady=10)