import customtkinter as CTk
import tkinter as tk
import tkcalendar as Calendar
import Database.HotelDatabase as hd
import datetime as dt
from datetime import *
import Code.order as order

class bookingFrame(CTk.CTkFrame):   
    def __init__(self, username, master, width, height):
        super().__init__(master, width, height)
        username=username
        # --create variables
        text = tk.StringVar()
        dateNOW = date.today()
        text.set("Unavailable")

        # --configure frame
        self.grid_propagate(False)

        # --create widgets
        infolabel = CTk.CTkLabel(self, textvariable=text)
        roomsTup = hd.getRooms()
        roomsList = ["Rooms Available"]
        for i in roomsTup:
            # --this for loop is used to convert the unchangable tuple into a list
            roomsList.append(i[0])

        def purchase_callback():
            # --callback for if the purchase button is clicked
            # --checks if the room is available or if there has no date been selected
            if text.get() == "Unavailable" or text.get() == "Click Date to View Avalablility" or text.get() == "This date is unavailable":
                text.set("This date is unavailable")
            else:
                # --checks the length of stay
                lenOfStayLocal = lenofstay.get()
                roomchoiceLocal = roomchoice.get()
                if lenOfStayLocal == "Number Of Days" or roomchoiceLocal == "Rooms Available":
                    # --checks if the length of stay is a real length and if there has been a room selected
                    pass
                else:
                    # --opens the purchase top level
                    self.top_win = order.PurchaseHotelTopLevel(self, username=username, room=roomchoiceLocal, dateOfVisit=widget.get_date(), lenofstay=lenOfStayLocal)
                    self.top_win.grab_set()
                    self.top_win.focus()
        # --defines the default variable for the days max list
        daysMax = ["Number Of Days"]
        for i in range(1,10): 
            # --add the days to the list
            daysMax.append(f"{i}")
        # --creates the len of stay option menu with the daysmax variable
        lenofstay = CTk.CTkOptionMenu(self, values=daysMax)
        # --creates the other variables
        roomchoice = CTk.CTkOptionMenu(self, values=roomsList)
        purchaseButton = CTk.CTkButton(self, text="Purchase", command=lambda : purchase_callback())
        widget = Calendar.Calendar(self, year=dateNOW.year, month=dateNOW.month, day=dateNOW.day)
        
        # --command to be bound to event below
        def getDate(self):
            # --defines variables
            roomStr = roomchoice.get()
            roomNum = ""
            for char in roomStr:
                # --this for loop takes each character in the roomstring
                if char.isdigit():
                    # --condeses into a string
                    roomNum=f"{roomNum}{char}"
            # --creates the date vaiable based off of what the date selected in the calendar
            dateVar = self.widget.get_date()
            # --reformat the date
            dateVar = datetime.strptime(dateVar, "%m/%d/%y")
            dateVar = dateVar.date()
            dateVar = str.split(dateVar.strftime("%d-%m-%Y"), "-")
            #gets of the date is available
            availableVar = hd.checkAvilTime(date(int(dateVar[2]),int(dateVar[1]),int(dateVar[0])), roomNum)
            if availableVar == True:
                text.set("Unavailable")
            else:
                text.set("Available")

        # --place widgets      
        widget.grid(row=0,column=1)
        infolabel.grid(row=1,column=1)
        lenofstay.grid(row=2, column=1)
        roomchoice.grid(row=3, column=1)
        purchaseButton.grid(row=4, column=1)

        # --bind widgets to command
        widget.bind("<<CalendarSelected>>", getDate)
