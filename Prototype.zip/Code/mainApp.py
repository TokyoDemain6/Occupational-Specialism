import customtkinter as CTk
from PIL import Image
import Code.MainPage
import Imports.CTkSlideview as CTkSlideview
from Code import Popups as popups

class AppMain(CTk.CTk):
    def __init__(self, username):
        super().__init__()
        logoPath="Assets\images\LogoZebra.png"
        logo = CTk.CTkImage(light_image=Image.open(logoPath), size=(100, 100))
        # --define variables and configure app
        username = username
        CTk.set_appearance_mode("dark")
        self.grid_propagate(False)
        self.title("main")
        self.geometry("1280x720")
        self.resizable(False, False)
        self.grid_columnconfigure(0,weight=1)
        CTkLogoFont = CTk.CTkFont(family="jejuGothic", size=21)
        #frames placed in position
        self.navbar = CTk.CTkFrame(self,width=1280,height=119)
        self.mainFrame = Code.MainPage.mainPage(master=self, username=username)
        self.navbar.grid(row=0,column=0,columnspan=2,sticky="nesw",pady=(0,3))
        self.mainFrame.grid(row=1,column=0,columnspan=2,sticky="nesw")
        #creates buttons and logos for navbar
        self.bookTickets = CTk.CTkButton(self.navbar,text="Book Tickets",width=250,height=70, fg_color="#FFB800", hover_color="#b58300", text_color="black", font=CTkLogoFont, command=lambda : self.book_ticket_open(username=username))
        self.checkAttractions = CTk.CTkButton(self.navbar,text="Check Attractions",width=250,height=70, font=CTkLogoFont,fg_color="#747474", hover_color="#595959",command=lambda : self.check_attractions_open(username=username))
        self.viewHotelBooking = CTk.CTkButton(self.navbar,text="View Hotel Booking",width=250,height=70, font=CTkLogoFont,fg_color="#747474", hover_color="#595959", command=lambda : self.check_hotel_open(username=username))
        self.logo = CTk.CTkLabel(self.navbar, image=logo, text="")
        self.logoText = CTk.CTkLabel(self.navbar, text="Ridget Zoo Adventures", font=CTkLogoFont)
        #places the buttons and logos on the grid in the navbar
        self.logo.grid(row=0,column=1)
        self.logoText.grid(row=0,column=2)
        self.bookTickets.grid(row=0,column=5,padx=10,pady=10,sticky="e")
        self.checkAttractions.grid(row=0,column=4,padx=10,pady=10,sticky="e")
        self.viewHotelBooking .grid(row=0, column=3,padx=10,pady=10,sticky="e")

        # --Command callback for opening the calendar popup window
    def book_ticket_open(self, username):
        self.toplevel_window = popups.PopupBookTicketOpen(username=username)
        self.toplevel_window.grab_set()
        self.toplevel_window.focus()

    # --Command callback from opening the check attractions window popup
    def check_attractions_open(self, username):
        self.toplevel_window = popups.popupCheckAttractionOpen(username=username)
        self.toplevel_window.grab_set()
        self.toplevel_window.focus()
    
    # --Command callback for opening the hotel attractions window popup
    def check_hotel_open(self,username):
        self.toplevel_window = popups.popupCheckHotelOpen(username=username)
        self.toplevel_window.grab_set()
        self.toplevel_window.focus()
