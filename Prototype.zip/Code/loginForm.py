import customtkinter as CTk 
import Database.UserDatabase as userbase
import Code.mainApp as mainApp

class App(CTk.CTk):
    def __init__(self):
        super().__init__()
        # --configures the frame
        self.resizable(False, False)
        self.title("Login")
        self.geometry("600x600")
        self.grid_columnconfigure((0, 0), weight=1)
        # --creates the frame and buttons
        self.mainLoginFrame = CTk.CTkFrame(self)
        self.mainLoginFrame.grid(row=0, column=0, padx=10, pady=10)
        self.titleLabel = CTk.CTkLabel(self.mainLoginFrame, text="Login/Signup")
        self.titleLabel.grid(row=0,column=0,columnspan=2, sticky="ew")
        self.usernameEntry = CTk.CTkEntry(self.mainLoginFrame, placeholder_text="username")
        self.usernameEntry.grid(row=1,column=0,padx=10,pady=10,columnspan=2,sticky="ew")
        self.passwordEntry = CTk.CTkEntry(self.mainLoginFrame, placeholder_text="password",show="*")
        self.passwordEntry.grid(row=2,column=0,padx=10,pady=10,columnspan=2,sticky="ew")
        self.loginButton = CTk.CTkButton(self.mainLoginFrame, text="Login", command=lambda : self.button_click("login"))
        self.signupButton = CTk.CTkButton(self.mainLoginFrame, text="Signup", command=lambda : self.button_click("signup"))
        self.loginButton.grid(row=3,column=0,padx=10,pady=10)
        self.signupButton.grid(row=3,column=1,padx=10,pady=10)
        self.termsAndConditions = CTk.CTkCheckBox(self.mainLoginFrame,text= "By checking this box you are agreeing to the \nterms and service of this program. \nThis is required for usage of this app", onvalue="Agreed", offvalue="NotAgreed")
        self.termsAndConditions.grid(row=4, column=0, columnspan=2,padx=10,pady=10)

    def button_click(self, type):
        # --this function is used as a callback for either of the button
        # --this if statement checks if the button that was placed is the login button or the signup button
        if type == "login":
            username = self.usernameEntry.get()
            password = self.passwordEntry.get()
            terms = self.termsAndConditions.get()
            print(username, password, terms)
            returned = userbase.login(username, password)
            # --this if statement checks if the password and username exist and if the t&cs have been clicked
            if returned[1] == True and terms == "Agreed":
                # --destroys the login form and starts the loop for the main app while passing in the current username
                self.destroy()
                app = mainApp.AppMain(username = username)
                app.mainloop()
            else:
                # --does nothing if something is incorrect 
                pass
        elif type == "signup":
            #creates variables that are available through functions outside of this one
            self.username = self.usernameEntry.get()
            self.password = self.passwordEntry.get()
            self.terms = self.termsAndConditions.get()
            # --this if statement checks if the username and password exist
            if self.username and self.password and self.terms == "Agreed":
                # --creates variables that are available externally
                self.email = ""
                self.phoneNumber = ""
                # --creates a popup window
                self.top = CTk.CTkToplevel(self)
                self.top.grab_set()
                self.top.focus()
                # -creates and places the extra entries and buttons for the signup on the popup page
                self.emailentry = CTk.CTkEntry(self.top,placeholder_text="email")
                self.emailentry.grid(row=0,column=0, padx=20,pady=20)
                self.phoneNumberEntry = CTk.CTkEntry(self.top,placeholder_text="Phone No.")
                self.phoneNumberEntry.grid(row=1,column=0, padx=20,pady=20)
                self.confirmButton = CTk.CTkButton(self.top,text="confirm", command=self.confirm_button_click)
                self.confirmButton.grid(row=2,column=0, padx=20,pady=20)
            
    def confirm_button_click(self):
        # --this function is a callback for if the confirm information button is clicked
        # --gets the data from teh topframe
        self.phoneNumber = self.phoneNumberEntry.get()
        self.email = self.emailentry.get()
        #creates the user in the database
        userbase.createUser(self.username, self.password, self.email, self.phoneNumber)
        #destroys the loginframe and opens the mainapp
        self.destroy()
        app = mainApp.AppMain(username=self.username)
        app.mainloop()
        
