import customtkinter as CTk
from PIL import Image
import Code.CalendarTickets as cal
from Code.Hotel import hotelFrame
import Database.AnimalDatabase as ad
import Database.helpers as helpers

class PopupBookTicketOpen(CTk.CTkToplevel):
    def __init__(self, username):
        super().__init__()
        # --configure window
        me = self
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.geometry("600x600")
        self.resizable(False, False)

        # --create variables
        username = username
        logoPath="Assets\images\LogoZebra.png"
        logo = CTk.CTkImage(light_image=Image.open(logoPath), size=(100, 100))

        def close():
            self.destroy()

        # --topBar
        self.top = CTk.CTkFrame(self, width=600, height=150)
        self.top.grid_propagate(False)
        self.logo = CTk.CTkLabel(self.top, image=logo, text="")
        self.logoText = CTk.CTkLabel(self.top, text="Ridget Zoo Adventures")
        self.topButton = CTk.CTkButton(self.top, 250, 72, command = lambda : close(), text="Quit")

        # --MainFrame
        self.mainFrame = cal.calendar(self, height=420, width=400, username=username,ticketpop=me)

        # --Placement - Top
        self.top.grid(row=0,column=0,sticky="nw")
        self.logo.grid(row=0,column=0,padx=10,pady=10)
        self.logoText.grid(row=0,column=1,padx=10,pady=10)
        self.topButton.grid(row=0,column=2,padx=10,pady=10)

        # --Placement - MainFrame
        self.mainFrame.grid(row=1,column=0)
        self.mainFrame.grid_rowconfigure(1, weight=1)
        self.mainFrame.grid_columnconfigure(1, weight=1)

class popupCheckHotelOpen(CTk.CTkToplevel):
    def __init__(self, username):
        super().__init__()
        # --configure window
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.geometry("600x600")
        self.resizable(False, False)

        def close():
            self.destroy()

        # --create variables
        username=username
        logoPath="Assets\images\LogoZebra.png"
        logo = CTk.CTkImage(light_image=Image.open(logoPath), size=(100, 100))

        # --topBar
        self.topbar = CTk.CTkFrame(self, width=600, height=150)
        self.topbar.grid_propagate(False)
        self.logo = CTk.CTkLabel(self.topbar, image=logo, text="")
        self.logoText = CTk.CTkLabel(self.topbar, text="Ridget Zoo Adventures")
        self.topButton = CTk.CTkButton(self.topbar, 250, 72, command = lambda : close(), text="Quit")

        # --MainFrame
        self.mainFrame = hotelFrame(self, 560, 400)

        # --placement - Top
        self.topbar.grid(row=0,column=0,sticky="nw")
        self.logo.grid(row=0,column=0,padx=10,pady=10)
        self.logoText.grid(row=0,column=1,padx=10,pady=10)
        self.topButton.grid(row=0,column=2,padx=10,pady=10)


        # --placement - mainFrame
        self.mainFrame.grid(row=1,column=0)
        self.mainFrame.grid_rowconfigure(1, weight=1)
        self.mainFrame.grid_columnconfigure(1, weight=1)



class popupCheckAttractionOpen(CTk.CTkToplevel):
    def __init__(self, username):
        super().__init__()
        # --configure window
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.geometry("600x600")
        self.resizable(False, False)

        # --create variables
        self.widgetDict = {"Animals" : []}
        username = username
        logoPath="Assets\images\LogoZebra.png"
        logo = CTk.CTkImage(light_image=Image.open(logoPath), size=(100, 100))

        # --create the command for closing
        def close():
            self.destroy()

        # --make main frame
        self.mainframe = CTk.CTkScrollableFrame(self,600,400)
        self.populate(mainframe=self.mainframe)
        
        # --top bar
        self.top = CTk.CTkFrame(self, width=600, height=150)
        self.top.grid_propagate(False)
        self.logo = CTk.CTkLabel(self.top, image=logo, text="")
        self.logoText = CTk.CTkLabel(self.top, text="Ridget Zoo Adventures")
        self.topButton = CTk.CTkButton(self.top, 250, 72, command = lambda : close(), text="Quit")
        self.mainframe.grid(row=1,column=0)


        # --placement - Top
        self.top.grid(row=0,column=0,sticky="nw")
        self.logo.grid(row=0,column=0,padx=10,pady=10)
        self.logoText.grid(row=0,column=1,padx=10,pady=10)
        self.topButton.grid(row=0,column=2,padx=10,pady=10)

    def updateDict(self, animaldata, labelname, labeldata, top, table, moveframe):
        # ---DEBUG COMMENT BELOW
        #print(f"self: {self}    animaldata: {animaldata}    labelname: {labelname}    labeldata: {labeldata}    top: {top}    table: {table}    moveframe: {moveframe}")
        # --places the variables in the dictionary based off the template
        dict = {f"{table[0]}" : {
                    f"{animaldata[0]}" : {
                        "name" : labelname,
                        "data" : labeldata,
                        "master" : moveframe
                    }
                }
            }
        # --places the afformentioned dicitonary in the sublist in the widgetdict dictionary
        self.widgetDict["Animals"].append(dict)



        
    def populate(self, mainframe):
        # --This function is used to put the frames on the mainframe by looping the creation of multiple instances and storing them in a dictionary for later manipulation
        # --Define variables
        tables = ad.readAnimalTables()
        count=0
        # --This loop creates a frame for an animal type for every table in the table names from the database
        for table in tables:
            # --Creates the frame for animal types
            self.animalType = subframeAnimalTypes(master=mainframe, table=table, top=self,count=count,mainwin=self)
            # --places the frame on the grid in mainframe
            self.animalType.grid(row=count,column=0)
            #increases the value of count
            count= count + 1

class subframeAnimalTypes(CTk.CTkScrollableFrame):
    def __init__(self,master,table,top,count,mainwin):
        super().__init__(master, 560,200,fg_color="#FFB800")
        # --define variables
        subcount=1
        # --configures the frame
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        # --Creates and places the labels on the frame
        self.labelAnimalType = CTk.CTkLabel(self, text=f"{table}",justify="left", text_color="black")
        self.labelAnimalType.grid(row=0,column=0,sticky="nw")
        # --Loop to create a subframe for every individual animal at the 
        subcount=subcount
        for animal in ad.readAnimalType(table):
            # --Creates an instance of the animal frame for every animal in the desired type
            self.aniWid = subframeIndividualAnimals(master=self, animaldata=animal, top=top,table=table,mainwin=mainwin)
            # --places the frame on the grid in the types frame
            self.aniWid.grid(row=subcount,column=0)
            # --increases the subcount
            subcount= subcount + 1




class subframeIndividualAnimals(CTk.CTkScrollableFrame):
    def __init__(self, master, animaldata, top:CTk.CTk,table, mainwin):
        super().__init__(master, 540,50,fg_color="green")
        # --Configures frame
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        # --Creates the labels for the text data about the animals
        self.labelAnimalName = CTk.CTkLabel(self, text=f"""animalname{animaldata[0]}""", justify="left")
        # TODO -- Needs to be formatted better
        self.labelAnimalData = CTk.CTkLabel(self, text=f"""animaldata{((helpers.stringToDict(animaldata[5])))}""",justify="left",wraplength=500)
        # --Updates the dictionary storing the labels for potential later manipulation
        mainwin.updateDict(animaldata=animaldata,labelname=self.labelAnimalName,labeldata=self.labelAnimalData,top=top,table=table, moveframe=self)
        # --Places the labels on the grid in the frame
        self.labelAnimalName.grid(row=0, column=0,sticky="nw")
        self.labelAnimalData.grid(row=1, column=0,sticky="nw")



