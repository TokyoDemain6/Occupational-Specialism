import customtkinter as CTk
import tkinter
import tkcalendar
import datetime as dt
from datetime import *
import json
import Database.TicketDatabase as td
import Code.order as order

class calendar(CTk.CTkFrame):
    def __init__(self, master, width, height, username,ticketpop):
        super().__init__(master, width, height)

        # --define variables
        text = tkinter.StringVar()
        text.set("Click Date to View Avalablility")
        dateNOW = date.today()
        f = open("OpenDays.json")
        f = json.load(f)
        days = {
            "0" : "monday",
            "1" : "tuesday",
            "2" : "wednesday",
            "3" : "thursday",
            "4" : "friday",
            "5" : "saturday",
            "6" : "sunday"
        }

        # --change settings
        self.grid_propagate(False)

        # --define widgets
        infolabel = CTk.CTkLabel(self, textvariable=text)
        widget = tkcalendar.Calendar(self, year=dateNOW.year, month=dateNOW.month, day=dateNOW.day)
        purchaseButton = CTk.CTkButton(self, text="Purchase")

        # --get date to update label upon the <<CalendarSelected>> virtual event
        def get_date(self):
            # --define variables
            dateVar = self.widget.get_date()
            #turn the date into a string
            dateVar = datetime.strptime(dateVar, "%m/%d/%y")
            # --turns the date string into a date object, could be refactored
            dateVar = dateVar.date()
            availableVar = dateVar.weekday()
            if f["open"][days[f"{availableVar}"]] == "false":
                # --this if statement checks if the room is available and chages the label text into the status of the room
                text.set("Unavailable")
            else:
                text.set("Available")

        def purchase_callback():
            # --callback for if the purchase button is clicked
            # --checks if the room is available or if there has no date been selected
            if text.get() == "Unavailable" or text.get() == "Click Date to View Avalablility" or text.get() == "This date is unavailable":
                text.set("This date is unavailable")
            else:
                # --opens the purchase top level
                self.top_win = order.PurchaseTicketTopLevel(self,username=username,dateOfVisit=widget.get_date(), ticketpop=ticketpop)
                self.top_win.grab_set()
                self.top_win.focus()

        # --place the widgets on the frame  
        widget.grid(row=0,column=1)
        infolabel.grid(row=1,column=1)
        purchaseButton.grid(row=3, column=1)

        # --bind the widget to the event and connect it to the function above
        purchaseButton.configure(False, command=purchase_callback)
        widget.bind("<<CalendarSelected>>", get_date)

