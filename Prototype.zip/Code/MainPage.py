import customtkinter as CTk
import tkinter as tkinter
from PIL import Image
import Database.AnimalDatabase as AnimalDatabase
import json
import Imports.CTkSlideview as CTkSlideview
from tkcalendar import Calendar
import Code.Calendar as calendar
from tkinter import Event

class mainPage(CTk.CTkScrollableFrame):
    def __init__(self, username, master):
        super().__init__(master)
        # --Define variables and configure the frame
        username=username
        f = open("mainAttractions.json")
        images = json.load(f)
        self.datas = []
        self.configure(height=600)
        image = CTk.CTkImage(light_image=Image.open("Assets/images/Zebra.png"),
                                  dark_image=Image.open("Assets/images/Zebra.png"),
                                  size=(1280, 709.75))
        self.mainImagelabel = CTk.CTkLabel(self, image=image, text="")
        c = "Left"
        count = 1
        for i in images:
            if c == "Right":
                side = "Left"
            else:
                side = "Right"
            # --defines variables
            name = images[i]["name"]
            animal=images[i]["animal"]
            path=images[i]["path"]
            # --creates the frame
            self.frame = dataFrame(self,name=name, animal=animal, path=path, side=side)
            # --configure the frame
            self.frame.grid_propagate(False)
            self.frame.configure(width=1280, height=494)
            # --places the frame
            self.frame.grid(row=int(i)+1, column=0,padx=10,pady=10)
            # --increases the value of count and adds the frame to the datas list
            count = int(i) + 1
            self.datas.append(self.frame)

        # --places the main image at the top of the page
        self.mainImagelabel.grid(row=0, column=0)
        # --creates and places the frame that contains the slideview
        self.slideMenuFrame = CTk.CTkFrame(self)
        self.slideMenuFrame.grid(row = count + 1)
        # --creates and places the slideview
        slideMenu = CTkSlideview.CTkSlideView(self.slideMenuFrame)
        slideMenu.grid(row=8,column=1)
        # --opens the json file that contains the main attrations
        j = open("SlideMenuAttractions.json")
        j = json.load(j)
        # --for every attraction in the file loops
        for i in range(0,j["noOfAttractions"]):
            x = j[f"{i+1}"]
            # --gets the data for the current animal
            animalData = AnimalDatabase.readAnimal(animalType=x["Animal"], animalName=x["Name"])
            # --seperates the data into different variables
            animalCharacteristics = animalData[5]
            description = animalCharacteristics["description"]
            Location = animalData[1]
            Age = animalData[2]
            Species = animalData[3]
            Habitat = animalData[4]
            name = x["Name"]
            # --creates a variable for the full description of the animal
            Descript = "Name: {name}\n{description}\nPark: {Location}\nAge: {Age}\nSpecies: {Species}\nHabitat: {Habitat}".format(description = description, Location = Location, Age = Age, Species = Species, Habitat = Habitat, name = name)
            # --creates and places the label containing the data
            self.label1 = CTk.CTkLabel(slideMenu.create_tab(), text=Descript, font=("SF Display", 50), wraplength=700).place(relx=0.5, rely=0.5, anchor="center")
        # --creates and places the calendar on the page
        calFrame = calendar.bookingFrame(master=self, username=username, width=400, height=400)
        calFrame.grid(row=9,column=0)

            

class dataFrame(CTk.CTkFrame):
    def __init__(self, master, name, path, animal, side):
        super().__init__(master)
        # --define variables
        self.TitleFont = CTk.CTkFont(self, size=40)
        self.RegularFont = CTk.CTkFont(self, size=20)
        image = CTk.CTkImage(light_image=Image.open(f"{path}"),
                                dark_image=Image.open(f"{path}"),
                                size=(529.64, 494.33))
        animalData = AnimalDatabase.readAnimal(animalType=animal, animalName=name)
        animalCharacteristics = animalData[5]
        description = animalCharacteristics["description"]
        Location, Age, Species, Habitat = animalData[1], animalData[2], animalData[3], animalData[4]
        Descript = "{description}\nPark: {Location}\nAge: {Age}\nSpecies: {Species}\nHabitat: {Habitat}".format(description = description, Location = Location, Age = Age, Species = Species, Habitat = Habitat)
        #creates the widgets that will hold the data
        self.ImageLabel = CTk.CTkLabel(self, text="", image=image)
        self.mainDescription = CTk.CTkLabel(self, text=Descript,font=self.RegularFont,justify="left", anchor="w")
        self.TextLabel = CTk.CTkLabel(self, text=name, font=self.TitleFont,justify="left", anchor="w")
        # --places the widgets
        self.ImageLabel.grid(row=0,column=0,rowspan=2,sticky="w", padx = 30, pady=30)
        self.TextLabel.grid(row=0,column=1,columnspan=3,sticky="w", padx = 30, pady=30)
        self.mainDescription.grid(row=1,column=1,columnspan=3,sticky="w", padx = 30, pady=30)
