import customtkinter as CTk
import Database.HotelDatabase as hd
import Database.helpers as helpers

class hotelFrame(CTk.CTkFrame):
    def __init__(self, master, width, height):
        super().__init__(master, width, height)
        # --configure frame
        self.grid_propagate(False)
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # --create variables
        self.dropdownvalue=CTk.StringVar(value="")
        self.roomnumber=CTk.StringVar(value="Waiting For Input")
        self.roomtype=CTk.StringVar(value="Waiting For Input")
        self.roomcost=CTk.StringVar(value="Waiting For Input")

        # --create widgets
        self.infoframe = CTk.CTkFrame(self,width=323,height=300)
        self.infoframe.grid_propagate(False)
        self.RoomDropdown = CTk.CTkComboBox(self, width=500)
        self.infoRoomNumber = CTk.CTkLabel(self.infoframe, width=275,height=75, textvariable=self.roomnumber)
        self.infoRoomType = CTk.CTkLabel(self.infoframe, width=275,height=75, textvariable=self.roomtype)
        self.infoCostPerNight = CTk.CTkLabel(self.infoframe, width=275,height=75, textvariable=self.roomcost)
        self.debuglabel = CTk.CTkLabel(self, textvariable=self.dropdownvalue)
        # --place widgets
        self.infoframe.grid(row=1, column=0, columnspan=2, rowspan=2, sticky="n")
        self.RoomDropdown.grid(row=0, column=0)
        self.infoRoomNumber.grid(row=0,column=0,sticky="n")
        self.infoRoomType.grid(row=1, column=0,sticky="n")
        self.infoCostPerNight.grid(row=2,column=0,sticky="n")
        self.debuglabel.grid(row=3, column=0)

        # --populate the dropdown
        def createRoomDropdown(dropdown):
            # --gets all rooms from the database
            roomlist=hd.getRooms()
            # --creates a list for the storage of the rooms due to formating issues with the data returned
            roomlistind = []
            for i in roomlist:
                # --loops for every room
                # --add the room to the list
                roomlistind.append(f"{i[0]}")
            # --adds the information to the dropdown
            dropdown.configure(values=roomlistind)

        createRoomDropdown(self.RoomDropdown)

        def dropdown_callback(choice):
            # --This funciton is a callback for if the dropdown varaible is changed
            # --defines variables
            roomid=choice
            roomdata = hd.getRoomData(roomid)
            roomdatadict = helpers.stringToDict(roomdata[0][3])
            roomnum = roomdatadict["roomNumber"]
            roomtype = roomdatadict["roomType"]
            roomprice = roomdatadict["priceOfRoom"]
            #sets the roominformation labels to the data given
            self.roomnumber.set(f"Room Number: {roomnum}")
            self.roomtype.set(f"Room Type: {roomtype}")
            self.roomcost.set(f"Room Price: {roomprice}")
    
        self.RoomDropdown.configure(variable=self.dropdownvalue.get(),command=dropdown_callback)



