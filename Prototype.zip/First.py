from Database import UserDatabase, HotelDatabase, AnimalDatabase, TicketDatabase
from subprocess import Popen

roomcount = int(input("How many rooms are in the hotel"))
HotelDatabase.populate(roomCount=roomcount)
f = Popen("install.bat")
stdout, stderr = f.communicate()
input("press any key to exit")