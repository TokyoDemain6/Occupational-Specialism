import Code.loginForm
import Code.mainApp

# app = Code.mainApp.AppMain()
# app.mainloop()


app = Code.loginForm.App()

app.mainloop()